ZhengYin
V00915261
In this assignment, the main problem is the thread coopertation. My design is broken which I think the double linked list should be a better way than the queue, but there is a serious problem
which in the "push_back" function. The result is give up on the double linked list and turn to queue. The second problem is customer thread can not read id properly, which lead to nothing is 
implement in to the customer thread. The third problem is the time element is always come out a negative result, which I found out my unit of different variable is different.